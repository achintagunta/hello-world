﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using docusign_solution;
using System.Collections.Generic;

namespace docusign_Test
{
    [TestClass]
    public class ClothesTemperatureUnitTest
    {
        [TestMethod]
        public void HotTemperatureTestMethod(string[] testList)
        {
            Console.WriteLine("************Hot Temperature Test Case************");
            Temperature hotResponseType = new HotTemperature();

            Clothes clothesType = new Clothes();
            Dictionary<int, string> clothesList = clothesList = clothesType.getHotClothes();

            bool tempStore;

            for (int i = 1; i < testList.Length; i++)
            {
                tempStore = hotResponseType.SpecificResponse(Int16.Parse(testList[i]));

                Console.WriteLine(tempStore);
            }
        }

        [TestMethod]
        public void ColdTemperatureTestMethod(string[] testList)
        {
            Console.WriteLine("************Cold Temperature Test Case************");

            Temperature coldResponseType = new ColdTemperature();

            Clothes clothesType = new Clothes();
            Dictionary<int, string> clothesList = clothesList = clothesType.getColdClothes();

            bool tempStore;

            for (int i = 1; i < testList.Length; i++)
            {
                tempStore = coldResponseType.SpecificResponse(Int16.Parse(testList[i]));

                Console.WriteLine(tempStore);
            }
        }
    }
}
