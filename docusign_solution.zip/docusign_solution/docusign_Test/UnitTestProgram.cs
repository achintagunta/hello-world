﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace docusign_Test
{
    class UnitTestProgram
    {
        static void Main(string[] args)
        {
            string[] hotTestList    = { "HOT", "8", "6", "4", "2", "1", "7" };
            string[] coldTestList   = { "Cold", "8", "6", "3", "4", "2", "5", "1", "7" };

            ClothesTemperatureUnitTest unitTestObject= new ClothesTemperatureUnitTest();
            unitTestObject.HotTemperatureTestMethod(hotTestList);
            unitTestObject.ColdTemperatureTestMethod(coldTestList);
        }
    }
}
