﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace docusign_solution
{
    class TemperatureFactorySupplier
    {
        public Temperature TemperatureType(int tempType)
        {
            switch (tempType)
            {
                /*Create HotTemperature instance*/
                case 1: return new HotTemperature();

                /*Create ColdTemperature instance*/
                case 2: return new ColdTemperature();
                
                default: return null;
            }
        }
    }
}
