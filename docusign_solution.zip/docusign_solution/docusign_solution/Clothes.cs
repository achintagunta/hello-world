﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace docusign_solution
{
    public class Clothes
    {
        /// <summary>
        /// A dictionary to hold all the Hot temperature type responses
        /// </summary>
        private Dictionary<int, string> HotClothes  = null;

        /// <summary>
        /// A dictionary to hold all the Cold temperature type responses
        /// </summary>
        private Dictionary<int, string> ColdClothes = null;

        /// <summary>
        /// Get all the HotClothes Responses
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, string> getHotClothes()
        {
            HotClothes = new Dictionary<int, string>();

            HotClothes.Add(1, "sandals");
            HotClothes.Add(2, "sun visor");
            HotClothes.Add(3, "fail");
            HotClothes.Add(4, "t-shirt");
            HotClothes.Add(5, "fail");
            HotClothes.Add(6, "shorts");
            HotClothes.Add(7, "leaving house");
            HotClothes.Add(8, "Removing PJs");

            return HotClothes;
        }

        /// <summary>
        /// Get all the ColdClothes Responses
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, string> getColdClothes()
        {
            ColdClothes = new Dictionary<int, string>();

            ColdClothes.Add(1, "boots");
            ColdClothes.Add(2, "hat");
            ColdClothes.Add(3, "socks");
            ColdClothes.Add(4, "shirt");
            ColdClothes.Add(5, "jacket");
            ColdClothes.Add(6, "pants");
            ColdClothes.Add(7, "leaving house");
            ColdClothes.Add(8, "Removing PJs");

            return ColdClothes;
        }
    }
}
