﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace docusign_solution
{
    public abstract class Temperature
    {
        /// <summary>
        /// A list to keep track of all the responses given by the user
        /// </summary>
        private List<int> trackResponse = new List<int>();

        /// <summary>
        /// The IdealResponse is considered, irrespective of the Temperatures (i.e.Cold or Hot) outside house.
        /// </summary>
        /// <param name="garmentNo"></param>
        /// <returns></returns>
        protected bool IdealResponse(int garmentNo)     
        {
            if (garmentNo == 8 && CountResponse() == 0) /*Make sure that 'remove pajamas'(8) is the first step */
                return AddResponse(garmentNo);
            else if(SearchResponse(8) == false)
                return false;

            if (SearchResponse(garmentNo))             /*Do not repeat a garment*/
                return false;

            if (garmentNo == 4 || garmentNo == 6)      /*'T-Shirt/Shirt'(4) and 'Shorts/Pants'(6) can be worn anytime*/
                return AddResponse(garmentNo);

            if (garmentNo == 2 && SearchResponse(4))   /*Before wearing 'SunVisor/Hat'(2), 'T-Shirt/Shirt'(4) must be worn*/
                return AddResponse(garmentNo);

            if (garmentNo == 1 && SearchResponse(6))   /*Before wearing 'Sandals/Boots'(1), 'Shorts/Pants'(6) must be worn*/
                return AddResponse(garmentNo);

            return true;
        }

        public abstract bool SpecificResponse(int garmentNo);

        /// <summary>
        /// Add responses in the tracking list.
        /// </summary>
        /// <param name="garmentNo"></param>
        /// <returns></returns>
        protected bool AddResponse(int garmentNo)
        {
            trackResponse.Add(garmentNo);
            return true;
        }

        /// <summary>
        /// Search responses from the tracking list.
        /// </summary>
        /// <param name="garmentNo"></param>
        /// <returns></returns>
        protected bool SearchResponse(int garmentNo)
        {
            if (trackResponse.Contains(garmentNo))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Count the number of responses in the tracking list.
        /// </summary>
        /// <param name="garmentNo"></param>
        /// <returns></returns>
        protected int CountResponse()
        {
            return trackResponse.Count;
        }
    }


    public class HotTemperature : Temperature
    {
        /// <summary>
        /// HotResponse is considered, when the temperature outside the house is HOT
        /// </summary>
        /// <param name="garmentNo"></param>
        /// <returns></returns>
        override public bool SpecificResponse(int garmentNo)       
        {
            if (base.IdealResponse(garmentNo) == false)             /*Consider the IdealResponse before considering HotResponse*/
                return false;

            /*Check for all tracked responses before 'leaving house'(7) */
            if (garmentNo == 7 && SearchResponse(8) && SearchResponse(6) &&
                SearchResponse(4) && SearchResponse(2) && SearchResponse(1))
                return AddResponse(garmentNo);
            else if (garmentNo == 7 && 
                       (!SearchResponse(8) || !SearchResponse(6) ||
                        !SearchResponse(4) || !SearchResponse(2) || !SearchResponse(1))
                    )
                return false;

            return true;
        }
    }

    public class ColdTemperature : Temperature
    {
        /// <summary>
        /// ColdResponse is considered, when the temperature outside the house is COLD
        /// </summary>
        /// <param name="garmentNo"></param>
        /// <returns></returns>
        override public bool SpecificResponse(int garmentNo)
        {
            if (base.IdealResponse(garmentNo) == false)/*Consider the IdealResponse before considering ColdResponse*/
                return false;

            if (garmentNo == 3)                        /*Add Response, if the user is wearing 'socks'(3)*/
                return AddResponse(garmentNo);

            if (garmentNo == 1 && SearchResponse(3))   /*Before adding 'footwear'(1) Response, 'socks'(3) must be worn*/
                return AddResponse(garmentNo);

            if (garmentNo == 5 && SearchResponse(4))   /*Before adding 'jacket'(5) Response, 'shirt'(4) must be worn*/
                return AddResponse(garmentNo);

            /*Check for all tracked responses before 'leaving house'(7) */
            if (garmentNo == 7 && SearchResponse(8) && SearchResponse(6) &&
                SearchResponse(5) && SearchResponse(4) && SearchResponse(3) &&
                SearchResponse(2) && SearchResponse(1))
                return AddResponse(garmentNo);
            else if (garmentNo == 7 &&
                       (!SearchResponse(8) || !SearchResponse(6) ||
                        !SearchResponse(5) || !SearchResponse(4) || !SearchResponse(3) ||
                        !SearchResponse(2) || !SearchResponse(1))
                    )
                return false;

            return true;
        }
    }

}
