﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace docusign_solution
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Input: ");
                List<string> inputStream = (Console.ReadLine()).Split(' ', ',').ToList<string>();
                inputStream.RemoveAll(item => item == "");

                int tmpStore;
                int inputCount = inputStream.Count();

                if (inputCount > 0)
                {
                    for (int i = 1; i < inputCount; i++)
                        if (Int16.Parse(inputStream[i]) < 1 || Int16.Parse(inputStream[i]) > 8)
                        {
                            Console.WriteLine("Input Error: Numeric Commands in between 1 and 8 are only allowed");
                            return;
                        }
                }
                else
                {
                    Console.WriteLine("Input Error: Input cannot be empty");
                    return;
                }

                TemperatureFactorySupplier temperatureResponseType = new TemperatureFactorySupplier();
                Temperature responseType = null;

                Clothes clothesType = new Clothes();
                Dictionary<int, string> clothesList = null;

                if (string.Compare(inputStream[0], "HOT", true) == 0)
                {
                    responseType = temperatureResponseType.TemperatureType(1);
                    clothesList = clothesType.getHotClothes();
                }
                else if (string.Compare(inputStream[0], "COLD", true) == 0)
                {
                    responseType = temperatureResponseType.TemperatureType(2);
                    clothesList = clothesType.getColdClothes();
                }
                else
                {
                    Console.WriteLine("Input Error: Temperature Type must be either 'HOT' or 'COLD'");
                    return;
                }

                Console.Write("Output: ");

                for (int i = 1; i < inputCount; i++)
                {
                    tmpStore = Int16.Parse(inputStream[i]);
                    if (responseType.SpecificResponse(tmpStore))
                    {
                        if (i != inputCount - 1)
                            Console.Write(clothesList[tmpStore] + ", ");
                        else
                            Console.WriteLine(clothesList[tmpStore]);
                    }
                    else
                    {
                        Console.Write("fail");
                        break;
                    }
                }

                Console.WriteLine("");
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(" Something went wrong!!! Please try again");
                //Console.WriteLine(ex);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(" Something went wrong!!! Please try again");
                //Console.WriteLine(ex);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(" Something went wrong!!! Please try again");
                //Console.WriteLine(ex);
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Something went wrong!!! Please try again");
                //Console.WriteLine(ex);
            }
        }
    }
}
